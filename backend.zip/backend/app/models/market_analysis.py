from pydantic import BaseModel


class MarketAnalysis(BaseModel):
    returns: dict
    volatility: dict
    trend: dict
    regime: dict
    strategy_scores: dict
    strategy: str
    strategy_decision: dict
    statistics: dict
    trade_signal: dict
    risk: dict
    position_size: dict
    trade_decision: dict
    breakout: dict